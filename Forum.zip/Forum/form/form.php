<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php
$server_name="localhost";
$username="root";
$password="";
$database_name="database123";

$conn=mysqli_connect($server_name,$username,$password,$database_name);
//Checking the connection
if(!$conn)
{
    die("Connection Failed:" . mysqli_connect_error());
}

if(isset($_POST['save']))
{
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $nic = $_POST['nic'];
    $address = $_POST['address'];
    $state = $_POST['state'];
    $email = $_POST['email'];
    $web = $_POST['web'];
    $description = $_POST['description'];
    $ability = $_POST['ability'];


    $sql_query = "INSERT INTO product_details (name,contact,nic,address,state,email,web,description,ability)
    VALUES('$name','$contact','$nic','$address','$state','$email','$web','$description','$ability')";


    if(mysqli_query($conn, $sql_query))
    {
       
       echo file_get_contents("../Added/Added.html"); 
    }
    else
    {
        echo "Error: " . $sql . "" . mysqli_error($conn);
    }
    mysqli_close($conn);
}

    /***************************** */
    $con = mysqli_connect("localhost","root","","image");

        if(isset($_POST['save']))
        {
            $file = $_FILES['image']['name'];

            $query = "INSERT INTO upload(image) VALUES('$file')";
            $res = mysqli_query($con,$query);
            
            if($res)
            {
                move_uploaded_file($_FILES['image']['tmp_name'],"./UploadedImages/$file");
            }
        }

?>
</body>
</html>